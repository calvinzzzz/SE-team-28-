module.exports = {
  checkNumbers: function(value1, value2){
    return value1 + value2;
  }
}
